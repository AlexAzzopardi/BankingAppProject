package com.group.model.service;

import com.group.entity.User;

public interface UserService {

	public User loginUser(User user);
	public User addUser(User user);
	public User getUserbyUserName(String userName);
	
}
